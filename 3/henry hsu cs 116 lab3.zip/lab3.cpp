#include "ccc_win.h"
#include <vector>
#include <iostream>

using namespace std;

class Car
{
	public:
		Car();
		Car(string owner, string driver, string model);
		void Plot(Point p, double scale);

	private:
		string m_model, m_owner, m_driver;
};

Car::Car() {}

Car::Car(string driver, string owner, string model)
{
	m_model = model;
	m_owner = owner;
	m_driver = driver;
}

void Car::Plot(Point p, double scale)
{
	double x = p.get_x();
	double y = p.get_y();

	// Below are plot points for chassis of the car
	Point car_1l(x - 1 * scale, y + 1 * scale) ;
	Point car_1r(x + 1 * scale, y + 1 * scale) ;
	Point car_2l(x - 2 * scale, y - 0 * scale) ;
	Point car_2r(x + 2 * scale, y - 0 * scale) ;
	Point car_3l(x - 3 * scale, y - 0 * scale) ;
	Point car_3r(x + 3 * scale, y - 0 * scale) ;
	Point car_4l(x - 3 * scale, y - 1 * scale) ;
	Point car_4r(x + 3 * scale, y - 1 * scale) ;

	Point f_wheel(x - 1.8 * scale, y - 1 * scale) ;
	Point r_wheel(x + 1.8 * scale, y - 1 * scale) ;

	Point driver(x - 1.25 * scale, y + 0.75 * scale) ;
	Point owner(x - 2.5 * scale, y * scale) ;
	Point model(x + 0.5 * scale, y * scale) ;

	// Below are the lines for the car
	Line car_roof(car_1l, car_1r) ;
	Line car_fwindow(car_1l, car_2l) ;
	Line car_rwindow(car_1r, car_2r) ;
	Line car_hood(car_2l, car_3l) ;
	Line car_boot(car_2r, car_3r) ;
	Line car_fbumper(car_3l, car_4l) ;
	Line car_rbumper(car_3r, car_4r) ;
	Line car_under(car_4l, car_4r) ;

	// Displays the car
	cwin << car_roof << car_fwindow << car_rwindow << car_hood << car_boot ;
	cwin << car_fbumper << car_rbumper << car_under ;
	cwin << Circle(f_wheel, 0.5 * scale) << Circle(r_wheel, 0.5 * scale) ;
	cwin << Message (driver, m_driver);
	cwin << Message (owner, m_owner);
	cwin << Message (model, m_model);
}

class Person
{
	public:
		Person();
		Person(string name);
		string GetName();

	private:
		string m_name;
};

Person::Person(){}
Person::Person(string name) {m_name=name;}

string Person::GetName() {return m_name;}


int ccc_win_main()
{
	vector <Car*> cars;
	vector <Person*> owner_driver;
	int car_num = 0;
	double scale = 1;

	Person driver_x ("henry");			// init owner_driver with a person
	owner_driver.push_back(&driver_x);


	do
	{
		car_num = cwin.get_int("How many cars (max of 3) are to be plotted? ");
	} while (car_num <1 or car_num > 3);


	for (int i = 0; i < car_num; i++)
	{
		Point pi = cwin.get_mouse("Please click on where this vehicle is to be plotted? ");


		string driver = cwin.get_string("Enter name of driver for this vehicle? ");
		Person driver_i(driver);

		int d = 0, o = 0;		// d is current driver index, o is current owner index

		for (int j = 0; j < owner_driver.size(); j++)
		{
			bool exist = false;

			if (driver == owner_driver[j]->GetName())
			{
				exist = true;
				if(exist) {d = j;}		// sets current driver index to i
//				cwin << Message (pi, i);
			}

			else
			{
				exist = false;
				owner_driver.push_back(&driver_i);
//				cwin << Message (pi, "not a hit");
			}
		}

		string owner = cwin.get_string("Who is the owner of this vehicle? ");
		Person owner_i(owner);

		for (int j = 0; j < owner_driver.size(); j++)
		{
			bool exist = false;
			if (owner == owner_driver[j]->GetName())
			{
				exist = true;
				if(exist) {o = j;}		// sets current owner index to i
			}
			else
			{
				owner_driver.push_back(&owner_i);
			}

		}
		string model = cwin.get_string("What is the model of this car? ");


		Car car_i(owner_driver[d]->GetName(), owner_driver[o]->GetName(), model);
		cars.push_back(&car_i);
		cars[i]->Plot(pi, scale);

	}



}

