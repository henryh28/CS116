#include <iostream>
#include <algorithm>
#include <vector>
#include "Set.h"



void Set::add(Set& set, int value) { data.push_back(value); }

void Set::remove(Set& set, int value)
{
	for (int i = 0; i < set.size(); i++)
	{
		if (data[i] == value) { data.erase(data.begin()+i); }
	}
}

int Set::size() { return data.size(); }
int Set::report(int index) { return data[index]; }

Set Set::operator|(Set target)
{
	std::vector <int> temp;	// stores combined value of set_1 & set_2
	std::vector <int> intersect;		// stores only intersection values
	Set return_set;

	for (int i = 0; i < size(); i++)		// copies set_1 values
	{ temp.push_back(report(i)); }

	for (int i = 0; i < target.size(); i++)	// coipies set_2 values
	{ temp.push_back(target.report(i));	}

	std::sort(temp.begin(), temp.end());			// sorts complete set

	for (int i = 0; i < (temp.size()-1); i++)
	{
		if (temp[i] == temp[i+1]) { intersect.push_back(temp[i]); }
	}

	for (int i = 0; i < intersect.size(); i++) { return_set.add(return_set, intersect[i]); }
	return return_set;
}

Set Set::operator&(Set target)
{
	std::vector <int> temp;	// stores combined value of set_1 & set_2
	Set return_set;

	for (int i = 0; i < size(); i++)		// copies set_1 values
	{ temp.push_back(report(i)); }

	for (int i = 0; i < target.size(); i++)	// coipies set_2 values
	{ temp.push_back(target.report(i));	}

	std::sort(temp.begin(), temp.end());			// sorts complete set
	temp.erase(unique(temp.begin(), temp.end()), temp.end());	// deletes duplicate values

	for (int i = 0; i < temp.size(); i++) { return_set.add(return_set, temp[i]); }

	return return_set;
}

std::ostream& operator<<(std::ostream& os, Set& target)
{
	for (int i = 0; i < target.size(); i++)
	{ os << target.data[i] << ", "; }

	return os;
}
