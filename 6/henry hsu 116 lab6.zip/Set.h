#ifndef SET_H
#define SET_H

#include <iostream>
#include <algorithm>
#include <vector>


class Set
{
	public:
		void add(Set& set, int value);
		void remove(Set& set, int value);
		int size ();
		int report(int index);

		Set operator| (Set target);
		Set operator&(Set target);
		friend std::ostream& operator<<(std::ostream& os, Set& target);

	private:
		std::vector <int> data;

};



#endif

