#include <iostream>
#include <algorithm>
#include <vector>
#include "Set.h"

using namespace std;

/**
Define a class Set that stores a finite set of integers.  (In a set, the order of
elements does not matter, and every element can occur at most once.)  Supply add
and remove member functions to add and remove set elements.  Overload the | and &
operators to compute the union and intersection of the set, and the << operator
to send the set contents to a stream.
*/

int main()
{
	Set set_1;
	Set set_2;

	set_1.add(set_1, 1);
	set_1.add(set_1, 2);
	set_1.add(set_1, 3);
	set_1.add(set_1, 4);
	set_1.add(set_1, 5);
	set_1.add(set_1, 6);
	set_1.add(set_1, 7);
	set_1.add(set_1, 8);
	set_1.add(set_1, 9);

	set_2.add(set_2, 2);
	set_2.add(set_2, 3);
	set_2.add(set_2, 4);
	set_2.add(set_2, 5);
	set_2.add(set_2, 6);

	cout << "Set 1 of " << set_1.size() << " elements consists of: " << endl;
	for (int i = 0; i < set_1.size(); i++)	// displays set_1
	{ cout << set_1.report(i) << ", "; }
	cout << endl;
	cout << "Set 2 of " << set_2.size() << " elements consists of: " << endl;
	for (int i = 0; i < set_2.size(); i++)	// displays set_2
	{ cout << set_2.report(i) << ", "; }

	cout << endl << endl;
	cout << "Removing value 3 from set 1 and value 5 from set 2" << endl;
	set_1.remove(set_1, 3);
	set_2.remove(set_2, 5);

	cout << "Set 1 of " << set_1.size() << " elements consists of: " << endl;
	for (int i = 0; i < set_1.size(); i++)	// displays set_1
	{ cout << set_1.report(i) << ", "; }
	cout << endl;
	cout << "Set 2 of " << set_2.size() << " elements consists of: " << endl;
	for (int i = 0; i < set_2.size(); i++)	// displays set_2
	{ cout << set_2.report(i) << ", "; }

	cout << endl;

	Set merged = set_1 & (set_2);
	Set sect = set_1 | (set_2);

	cout << endl << "The union of the two sets are: " << endl;
	cout << merged;
	cout << endl << "The intersection of the two sets are: " << endl;
	cout << sect;

return 0;
}















