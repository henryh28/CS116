#include "ccc_win.h"
#include <vector>
#include <iostream>

using namespace std;

class Vehicle								// Base vehicle class
{
	public:
		Vehicle();
		virtual void Plot(Point p, double scale);		// virtual function

	private:
};

Vehicle::Vehicle() {}						// Default constructor


void Vehicle::Plot(Point p, double scale)	// Virtual function
{
	Point error = cwin.get_mouse("I should never see this.  error stub. ");
}


class Car : public Vehicle					// Derived car class
{
	public:
		virtual void Plot(Point p, double scale);		// virtual member function

	private:
};


void Car::Plot(Point p, double scale)		// Plots the car objects
{
	double x = p.get_x();
	double y = p.get_y();

	// Below are plot points for chassis of the car
	Point car_1l(x - 1 * scale, y + 1 * scale) ;
	Point car_1r(x + 1 * scale, y + 1 * scale) ;
	Point car_2l(x - 2 * scale, y - 0 * scale) ;
	Point car_2r(x + 2 * scale, y - 0 * scale) ;
	Point car_3l(x - 3 * scale, y - 0 * scale) ;
	Point car_3r(x + 3 * scale, y - 0 * scale) ;
	Point car_4l(x - 3 * scale, y - 1 * scale) ;
	Point car_4r(x + 3 * scale, y - 1 * scale) ;

	Point f_wheel(x - 1.8 * scale, y - 1 * scale) ;
	Point r_wheel(x + 1.8 * scale, y - 1 * scale) ;

	Point car(x - .5 * scale, y - 1.5 * scale) ;

	// Below are the lines for the car
	Line car_roof(car_1l, car_1r) ;
	Line car_fwindow(car_1l, car_2l) ;
	Line car_rwindow(car_1r, car_2r) ;
	Line car_hood(car_2l, car_3l) ;
	Line car_boot(car_2r, car_3r) ;
	Line car_fbumper(car_3l, car_4l) ;
	Line car_rbumper(car_3r, car_4r) ;
	Line car_under(car_4l, car_4r) ;

	// Displays the car
	cwin << car_roof << car_fwindow << car_rwindow << car_hood << car_boot ;
	cwin << car_fbumper << car_rbumper << car_under ;
	cwin << Circle(f_wheel, 0.5 * scale) << Circle(r_wheel, 0.5 * scale) ;
	cwin << Message (car, "Car");
}


class Truck : public Vehicle				// Derived truck class
{
	public:
		virtual void Plot(Point p, double scale);

	private:
};


void Truck::Plot(Point p, double scale)		// Plots the truck objects
{
	double x = p.get_x();
	double y = p.get_y();

	// Below are plot points for chassis of the space truck
	Point air_1(x * scale, y + 2 * scale) ;
	Point air_2l(x - 0.75 * scale, y + 1.25 * scale) ;
	Point air_2r(x + 0.75 * scale, y + 1.25 * scale) ;
	Point air_3l(x - 1.05 * scale, y + 0.35 * scale) ;
	Point air_3r(x + 1.05 * scale, y + 0.35 * scale) ;
	Point air_4l(x - 1 * scale, y - .65 * scale) ;
	Point air_4r(x + 1 * scale, y - .65 * scale) ;
	Point air_5l(x - 2.15 * scale, y - 1.25 * scale) ;
	Point air_5r(x + 2.15 * scale, y - 1.25 * scale) ;
	Point air_6l(x - 2.55 * scale, y - 2 * scale) ;
	Point air_6r(x + 2.55 * scale, y - 2 * scale) ;

	Point canopy(x * scale, y + 0.75 * scale) ;
	Point space_truck(x - 1 * scale, y - 2.5 * scale);

	// Below are the lines for the space truck
	Line airl_1l(air_1, air_2l) ;
	Line airl_1r(air_1, air_2r) ;
	Line airl_2l(air_2l, air_3l) ;
	Line airl_2r(air_2r, air_3r) ;
	Line airl_3l(air_3l, air_4l) ;
	Line airl_3r(air_3r, air_4r) ;
	Line airl_4l(air_4l, air_5l) ;
	Line airl_4r(air_4r, air_5r) ;
	Line airl_5l(air_5l, air_6l) ;
	Line airl_5r(air_5r, air_6r) ;
	Line airl_bot(air_6l, air_6r) ;

	// Displays the space truck
	cwin << airl_1l << airl_1r << airl_2l << airl_2r << airl_3l << airl_3r ;
	cwin << airl_4l << airl_4r << airl_5l << airl_5r << airl_bot ;
	cwin << Circle(canopy, 0.4 * scale) ;
	cwin << Message (space_truck, "Space Truck");

}


class Ufo: public Vehicle							// Derived ufo class
{
	public:
		virtual void Plot(Point p, double scale);

	private:
};


void Ufo::Plot(Point p, double scale)				// Plots the ufo objects
{
	double x = p.get_x();
	double y = p.get_y();

	Point ufo_1(x * scale, y * scale) ;
	Point ufo(x * scale, y - 2 * scale) ;

	cwin << Circle(ufo_1, 1 * scale) ;
	cwin << Message (ufo, "UFO");
}

int ccc_win_main()
{
	vector <Vehicle*> vehicles;
	int vehicle_size = 0;
	double scale = 1;


	do
	{
		vehicle_size = cwin.get_int("How many vehicles (max of 10) are to be plotted? ");
	} while (vehicle_size <1 or vehicle_size > 10);


	for (int i = 0; i < vehicle_size; i++)
	{
		Point pi = cwin.get_mouse("Please click on where vehicle is to be plotted? ");

		// The following loops will display the various objects in sequence
		if (i % 2 == 0)
		{
			Car car_i;
			vehicles.push_back(&car_i);
		}
		if (i % 2 == 1)
		{
			Ufo ufo_i;
			vehicles.push_back(&ufo_i);
		}
		else
		{
			Truck truck_i;
			vehicles.push_back(&truck_i);
		}

	vehicles[i]->Plot(pi, scale);

	}
}


