#include <iostream>
#include <iomanip>
#include "map.h"

using namespace std;

string main_menu()
{
	string menu_option;

	cout << " ------------------------------------------ " << endl;
	cout << "|               Map Lab v1.0a              |" << endl;
	cout << " ------------------------------------------ " << endl;
	cout << left << setw(38) << "I)nsert key";
	cout << "C)heck for key" << endl;
	cout << left << setw(38) << "R)emove a key";
	cout << "Q)uit" << endl;
	cin >> menu_option;
	cout << endl;
	menu_option[0] = toupper(menu_option [0]);
	menu_option.resize(1);
	return menu_option;
}


void insert_key(Map<string,string>& lab_map )
{
	string key;
	string value;
	cout << "Please enter a name for the key: ";
	cin >> key;
	cout << "Please enter a value to associate with the key: ";
	cin >> value;

	lab_map.insert(key, value);
	cout << key << " has been added to the map" << endl << endl;
}

void check_key(Map<string,string>& lab_map )
{
	string key;
	cout << "Please enter the key you want to search for: ";
	cin >> key;

	if(lab_map.contains_key(key))
	{ cout << "Associated value: " << lab_map.value_of(key) << endl << endl;}
	else
	{ cout << key << " not found in database!" << endl << endl;}
}

void remove_key(Map<string,string>& lab_map )
{
	string key;
	cout << "Please enter the key you want to remove: ";
	cin >> key;

	if(lab_map.contains_key(key))
		{ lab_map.remove_key(key); }
	else
		{ cout << key << " not found in database!" << endl << endl;}

}


int main()
{
	string term, menu_option;
	Map <string, string> lab_map;

	while (menu_option != "Q")
	{
		menu_option = main_menu();

		if (menu_option == "I")
		{
			insert_key(lab_map);
		}
		else if (menu_option == "C")
		{
			check_key(lab_map);
		}
		else if (menu_option == "R")
		{
			remove_key(lab_map);
		}
	}
}










