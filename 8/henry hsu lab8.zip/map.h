#include <iostream>
#include "list.h"
#include "pair.h"

template<typename F, typename S>
class Map
{
	public:
		Map(const F& a = F(), const S& b = S());

		void insert(const F& a = F(), const S& b = S());
		bool contains_key(const F& a = F());
		S value_of(const F& a = F());
		void remove_key(const F& a = F());

	private:
		F first;
		S second;

		List<Pair<F, S> > list_map;
};

template <typename F, typename S>
Map <F, S>::Map(const F& a, const S& b)
{
	first = a;
	second = b;
}

template<typename F, typename S>
void Map<F, S>::insert(const F& key, const S& value)
{
    Pair<F, S> p(key, value);
	list_map.push_back(p);
}

template<typename F, typename S>
bool Map<F, S>::contains_key(const F& key)
{
    Iterator<Pair<F, S> > iter = list_map.begin();
    while(!iter.equals(list_map.end()))
    {
		Pair<F, S> test = iter.get();
    	F test_key = test.get_first();
		if(test_key == key) { return true; }
		iter.next();
	}
	return false;
}

template<typename F, typename S>
S Map<F, S>::value_of(const F& key)
{
	Iterator<Pair<F, S> > iter = list_map.begin();
	while(!iter.equals(list_map.end()))
		{
			Pair<F, S> test = iter.get();
			F test_key = test.get_first();
			if(test_key == key) {return test.get_second();}
			iter.next();
		}
}

template<typename F, typename S>
void Map<F,S>::remove_key(const F& key)
{
	Iterator<Pair<F, S> > iter = list_map.begin();
	while(!iter.equals(list_map.end()))
	    {
			Pair<F, S> test = iter.get();
	    	F test_key = test.get_first();
			if(test_key == key) {list_map.erase(iter);}
			iter.next();
		}
}
