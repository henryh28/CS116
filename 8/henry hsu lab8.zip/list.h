#include <string>
#include <iostream>
#include <cassert>

using namespace std;
template<typename T> class List;
template<typename T> class Iterator;

template<typename T>
class Node
{
public:
   /**
      Constructs a node with a given data value.
      @param s the data to store in this node
   */
   Node(T s);
private:
   T data;
   Node* previous;
   Node* next;
friend class List<T>;
friend class Iterator<T>;
};

template<typename T>
class List
{
public:
   /**
      Constructs an empty list;
   */
   List();
   /**
      Appends an element to the list.
      @param data the value to append
   */
   void push_back(T data);
   /**
      Inserts an element into the list.
      @param iter the position before which to insert
      @param s the value to append
   */
   void insert(Iterator<T> iter, T s);
   /**
      Removes an element from the list.
      @param iter the position to remove
      @return an iterator pointing to the element after the
      erased element
   */
   Iterator<T> erase(Iterator<T> iter);
   /**
      Gets the beginning position of the list.
      @return an iterator pointing to the beginning of the list
   */
   Iterator<T> begin();
   /**
      Gets the past-the-end position of the list.
      @return an iterator pointing past the end of the list
   */
   Iterator<T> end();
private:
   Node<T>* first;
   Node<T>* last;
friend class Iterator<T>;
};

template<typename T>
class Iterator
{
public:
   /**
      Constructs an iterator that does not point into any list.
   */
   Iterator();
   /**
      Looks up the value at a position.
      @return the value of the node to which the iterator points
   */
   T get() const;
   /**
      Advances the iterator to the next node.
   */
   void next();
   /**
      Moves the iterator to the previous node.
   */
   void previous();
   /**
      Compares two iterators
      @param b the iterator to compare with this iterator
      @return true if this iterator and b are equal
   */
   bool equals(Iterator b) const;
private:
   Node<T>* position;
   List<T>* container;
friend class List<T>;
};

template<typename T>
Node<T>::Node(T s)
{
   data = s;
   previous = NULL;
   next = NULL;
}

template<typename T>
List<T>::List()
{
   first = NULL;
   last = NULL;
}

template<typename T>
void List<T>::push_back(T data)
{
   Node<T>* new_node = new Node<T>(data);
   if (last == NULL) // List is empty
   {
      first = new_node;
      last = new_node;
   }
   else
   {
      new_node->previous = last;
      last->next = new_node;
      last = new_node;
   }
}

template<typename T>
void List<T>::insert(Iterator<T> iter, T s)
{
   if (iter.position == NULL)
   {
      push_back(s);
      return;
   }

   Node<T>* after = iter.position;
   Node<T>* before = after->previous;
   Node<T>* new_node = new Node<T>(s);
   new_node->previous = before;
   new_node->next = after;
   after->previous = new_node;
   if (before == NULL) // Insert at beginning
      first = new_node;
   else
      before->next = new_node;
}

template<typename T>
Iterator<T> List<T>::erase(Iterator<T> iter)
{
   assert(iter.position != NULL);
   Node<T>* remove = iter.position;
   Node<T>* before = remove->previous;
   Node<T>* after = remove->next;
   if (remove == first)
      first = after;
   else
      before->next = after;
   if (remove == last)
      last = before;
   else
      after->previous = before;
   delete remove;
   Iterator<T> r;
   r.position = after;
   r.container = this;
   return r;
}

template<typename T>
Iterator<T> List<T>::begin()
{
   Iterator<T> iter;
   iter.position = first;
   iter.container = this;
   return iter;
}

template<typename T>
Iterator<T> List<T>::end()
{
   Iterator<T> iter;
   iter.position = NULL;
   iter.container = this;
   return iter;
}

template<typename T>
Iterator<T>::Iterator()
{
   position = NULL;
   container = NULL;
}

template<typename T>
T Iterator<T>::get() const
{
   assert(position != NULL);
   return position->data;
}

template<typename T>
void Iterator<T>::next()
{
   assert(position != NULL);
   position = position->next;
}

template<typename T>
void Iterator<T>::previous()
{
   assert(position != container->first);
   if (position == NULL)
      position = container->last;
   else
      position = position->previous;
}

template<typename T>
bool Iterator<T>::equals(Iterator<T> b) const
{
   return position == b.position;
}
