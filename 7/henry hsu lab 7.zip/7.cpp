#include "ccc_win.h"
#include "memTrack.h"
#include <vector>
#include <iostream>

using namespace std;

class Tile
{
	public:
		Tile();
		Tile(string data);
		~Tile();
		void Plot(double x, double y, double scale);
		string Flip(vector <Tile*> GameTiles, Point p);
		void Done();

	private:
		string value;
		int completed;
};

Tile::Tile() {}
Tile::Tile(string data):value(data){completed = 0;}
Tile::~Tile() {}

void Tile::Plot(double x, double y, double scale)
{
	// Below are plot points for the tile
	Point tile_ul(x - 1 * scale, y + 1 * scale);
	Point tile_ur(x + 1 * scale, y + 1 * scale);
	Point tile_ll(x - 1 * scale, y - 1 * scale);
	Point tile_lr(x + 1 * scale, y - 1 * scale);
	Point msg(x - 0.75 * scale, y );

	// Below are the lines for the tile
	Line tile_top(tile_ul, tile_ur);
	Line tile_left(tile_ul, tile_ll);
	Line tile_right(tile_ur, tile_lr);
	Line tile_bottom(tile_ll, tile_lr);

	// Displays the tile
	cwin << tile_top << tile_left << tile_right << tile_bottom;
}

string Tile::Flip(vector <Tile*> GameTiles, Point p)
{
	cwin << Message (p, value);
	return value;
}

void Tile::Done()
{
	value = "Success!";
}
string PlayGame(int& remaining, vector <Tile*> GameTiles, string previous, int& steps)
{
	Point p = cwin.get_mouse("Click on a tile");
	int x = p.get_x();
	int y = p.get_y();
	int mark = 0;
	string match_me;

	if(x > -7.75 && x < -4.5)
		if (y < 7.5 && y > 4.45) { match_me = GameTiles[0]->Flip (GameTiles, p); mark = 0; }
	if(x > -7.75 && x < -4.5)
		if (y < 2.7 && y > -0.5) { match_me = GameTiles[4]->Flip (GameTiles, p); mark = 4;}
	if(x > -7.75 && x < -4.5)
		if (y < -2.3 && y > -5.65) { match_me = GameTiles[8]->Flip (GameTiles, p); mark = 8; }
	if (x > -3.7 && x < -0.3)
		if (y < 7.5 && y > 4.45) { match_me = GameTiles[1]->Flip (GameTiles, p); mark = 1;}
	if (x > -3.7 && x < -0.3)
		if (y < 2.7 && y > -0.5) { match_me = GameTiles[5]->Flip (GameTiles, p); mark = 5;}
	if (x > -3.7 && x < -0.3)
		if (y < -2.3 && y > -5.65) { match_me = GameTiles[9]->Flip (GameTiles, p); mark = 9; }
	if (x > .2 && x < 3.7)
		if (y < 7.5 && y > 4.45) { match_me = GameTiles[2]->Flip (GameTiles, p); mark = 2;}
	if (x > .2 && x < 3.7)
		if (y < 2.7 && y > -0.5) { match_me = GameTiles[6]->Flip (GameTiles, p); mark = 6;}
	if (x > .2 && x < 3.7)
		if (y < -2.3 && y > -5.65) { match_me = GameTiles[10]->Flip (GameTiles, p); mark = 10;}
	if (x > 4.25 && x < 7.7)
		if (y < 7.5 && y > 4.45) { match_me = GameTiles[3]->Flip (GameTiles, p); mark = 3;}
	if (x > 4.25 && x < 7.7)
		if (y < 2.7 && y > -0.5) { match_me = GameTiles[7]->Flip (GameTiles, p); mark = 7;}
	if (x > 4.25 && x < 7.7)
		if (y < -2.3 && y > -5.65) { match_me = GameTiles[11]->Flip (GameTiles, p); mark = 11;}

	if (match_me == previous) {remaining--;}

	steps++;
	return match_me;
}


void display_grid (vector <Tile*>  GameTiles)
{
	cwin.clear();
	double scale = 1.75;

	GameTiles[0]->Plot(-6, 6, scale);
	GameTiles[1]->Plot(-2, 6, scale);
	GameTiles[2]->Plot(2, 6, scale);
	GameTiles[3]->Plot(6, 6, scale);
	GameTiles[4]->Plot(-6, 1, scale);
	GameTiles[5]->Plot(-2, 1, scale);
	GameTiles[6]->Plot(2, 1, scale);
	GameTiles[7]->Plot(6, 1, scale);
	GameTiles[8]->Plot(-6, -4, scale);
	GameTiles[9]->Plot(-2, -4, scale);
	GameTiles[10]->Plot(2, -4, scale);
	GameTiles[11]->Plot(6, -4, scale);
}

int ccc_win_main()
{
	vector <Tile*> GameTiles;
	int remaining = 6, steps = 0;
	string set_1 = "dog", set_2 = "cat", set_3 = "bear", set_4 = "bird",set_5 = "fish", set_6 = "panda";
	string click_1, click_2;

	void TrackListMemoryUsage();

	Tile tile_1(set_1), tile_2(set_2), tile_3(set_3), tile_4(set_4), tile_5(set_5), tile_6(set_6);
	Tile tile_7(set_1), tile_8(set_2), tile_9(set_3), tile_10(set_4), tile_11(set_5), tile_12(set_6);

	GameTiles.push_back(&tile_1);
	GameTiles.push_back(&tile_2);
	GameTiles.push_back(&tile_3);
	GameTiles.push_back(&tile_4);
	GameTiles.push_back(&tile_5);
	GameTiles.push_back(&tile_6);
	GameTiles.push_back(&tile_7);
	GameTiles.push_back(&tile_8);
	GameTiles.push_back(&tile_9);
	GameTiles.push_back(&tile_10);
	GameTiles.push_back(&tile_11);
	GameTiles.push_back(&tile_12);

	display_grid(GameTiles);
	Point yeay = cwin.get_mouse("click on where you would like for messages to be displayed?");

	do
	{
		click_1 = PlayGame(remaining, GameTiles, "", steps);
		click_2 = PlayGame(remaining, GameTiles, click_1, steps);
		Point pause = cwin.get_mouse("Click to continue");
	}while (remaining != 0);

	cwin << Message (yeay, (steps/2));
	cwin << Message (yeay, "    total attempts to win this current game.");
}


